package com.rideforfree.service;

import java.util.List;

import com.rideforfree.model.Ride;

public interface RideService {

	List<Ride> getRides();

}