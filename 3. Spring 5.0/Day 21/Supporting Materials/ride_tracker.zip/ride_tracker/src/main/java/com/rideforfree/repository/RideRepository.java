package com.rideforfree.repository;

import java.util.List;

import com.rideforfree.model.Ride;

public interface RideRepository {

	List<Ride> getRides();

}